import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const Products = ({ coffeeProducts, handleFeatureClick }) => {
  if (!coffeeProducts || coffeeProducts.length === 0) {
    return (
        <section id="products" className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                 <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Coffee Selection</h2>
                 <p className="text-xl text-gray-600">Loading delicious coffee...</p>
            </div>
        </section>
    );
  }

  return (
    <section id="products" className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Coffee Selection</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our collection of premium coffees, sourced and roasted with passion.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {coffeeProducts.map((product, index) => (
            <motion.div
              key={product.id || index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col"
            >
              <div className="relative">
                <img
                  alt={product.images.edges[0]?.node.altText || product.title}
                  className="w-full h-48 object-cover"
                  src={product.images.edges[0]?.node.url || "https://images.unsplash.com/photo-1511920183353-3c9ba4fe5545"} />
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.title}</h3>
                <div className="text-gray-600 mb-4 text-sm h-24 overflow-auto" dangerouslySetInnerHTML={{ __html: product.descriptionHtml }} />
                <div className="flex justify-between items-center mt-auto pt-4">
                  <span className="text-2xl font-bold text-amber-600">
                    ${parseFloat(product.priceRange.minVariantPrice.amount).toFixed(2)}
                  </span>
                  <Button
                    onClick={handleFeatureClick}
                    className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white"
                  >
                    Add to Cart
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;