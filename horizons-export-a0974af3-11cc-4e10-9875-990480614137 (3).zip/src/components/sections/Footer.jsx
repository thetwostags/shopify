import React from 'react';

const Footer = ({ handleFeatureClick }) => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/a0974af3-11cc-4e10-9875-990480614137/ba6ad61256c4c6c40e59f4fb8d87d758.jpg";

  return (
    <footer id="contact" className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src={logoUrl} alt="Two Stags Coffee Logo" className="h-12 w-auto" />
              <span className="text-2xl font-bold">Two Stags Coffee</span>
            </div>
            <p className="text-gray-400 mb-4">
              Premium artisan coffee delivered fresh to your door.
              Experience the world's finest coffee beans.
            </p>
          </div>

          <div>
            <span className="text-lg font-semibold mb-4 block">Quick Links</span>
            <div className="space-y-2">
              <a href="#home" className="text-gray-400 hover:text-white transition-colors block">Home</a>
              <a href="#products" className="text-gray-400 hover:text-white transition-colors block">Coffee</a>
              <a href="#about" className="text-gray-400 hover:text-white transition-colors block">About</a>
            </div>
          </div>

          <div>
            <span className="text-lg font-semibold mb-4 block">Customer Care</span>
            <div className="space-y-2">
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Shipping Info</button>
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Returns</button>
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">FAQ</button>
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Support</button>
            </div>
          </div>

          <div>
            <span className="text-lg font-semibold mb-4 block">Connect</span>
            <div className="space-y-2">
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Newsletter</button>
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Instagram</button>
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Facebook</button>
              <button onClick={handleFeatureClick} className="text-gray-400 hover:text-white transition-colors block text-left">Twitter</button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Two Stags Coffee. All rights reserved. Powered by Dripshipper.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;