import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const CTA = ({ handleFeatureClick }) => {
  return (
    <section className="py-20 bg-gradient-to-r from-amber-600 to-orange-600">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Taste the Difference?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of coffee lovers who have discovered their perfect cup with Two Stags Coffee.
            Free shipping on orders over $50!
          </p>
          <Button
            onClick={handleFeatureClick}
            size="lg"
            className="bg-white text-amber-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
          >
            Start Your Coffee Journey
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default CTA;