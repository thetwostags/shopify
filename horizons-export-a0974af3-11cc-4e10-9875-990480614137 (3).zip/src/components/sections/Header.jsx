import React from 'react';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = ({ handleFeatureClick }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/a0974af3-11cc-4e10-9875-990480614137/ba6ad61256c4c6c40e59f4fb8d87d758.jpg";

  return (
    <header className="fixed top-0 w-full bg-white/90 backdrop-blur-md shadow-lg z-50 border-b border-amber-200">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <motion.a
            href="#home"
            className="flex items-center space-x-3"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <img src={logoUrl} alt="Two Stags Coffee Logo" className="h-16 w-auto" />
            <span className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent hidden sm:block">
              Two Stags Coffee
            </span>
          </motion.a>

          <div className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Home</a>
            <a href="#products" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Coffee</a>
            <a href="#about" className="text-gray-700 hover:text-amber-600 transition-colors font-medium">About</a>
            <Button onClick={handleFeatureClick} className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white">
              Shop Now
            </Button>
          </div>

          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {isMenuOpen && (
          <motion.div
            className="md:hidden py-4 border-t border-amber-200"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex flex-col space-y-4">
              <a href="#home" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Home</a>
              <a href="#products" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-amber-600 transition-colors font-medium">Coffee</a>
              <a href="#about" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-amber-600 transition-colors font-medium">About</a>
              <Button onClick={() => { handleFeatureClick(); setIsMenuOpen(false); }} className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white w-fit">
                Shop Now
              </Button>
            </div>
          </motion.div>
        )}
      </nav>
    </header>
  );
};

export default Header;