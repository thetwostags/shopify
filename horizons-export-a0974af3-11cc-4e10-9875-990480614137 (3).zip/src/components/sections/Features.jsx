import React from 'react';
import { motion } from 'framer-motion';
import { Coffee, Truck, Shield, Heart } from 'lucide-react';

const featuresData = [
  {
    icon: <Coffee className="h-12 w-12 text-amber-600" />,
    title: "Premium Quality",
    description: "Sourced from the world's finest coffee regions and roasted to perfection"
  },
  {
    icon: <Truck className="h-12 w-12 text-amber-600" />,
    title: "Fast Shipping",
    description: "Fresh coffee delivered to your door with our reliable shipping partners"
  },
  {
    icon: <Shield className="h-12 w-12 text-amber-600" />,
    title: "Quality Guarantee",
    description: "100% satisfaction guaranteed or your money back, no questions asked"
  },
  {
    icon: <Heart className="h-12 w-12 text-amber-600" />,
    title: "Ethically Sourced",
    description: "Supporting sustainable farming practices and fair trade partnerships"
  }
];

const Features = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Two Stags Coffee?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We partner with Dripshipper to bring you the finest coffee experience with unmatched quality and convenience.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuresData.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="text-center p-6 rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;