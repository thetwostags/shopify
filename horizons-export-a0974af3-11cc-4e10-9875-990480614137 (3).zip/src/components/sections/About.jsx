import React from 'react';
import { motion } from 'framer-motion';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img
              alt="Coffee roasting process showing artisan craftsmanship and attention to detail"
              className="w-full h-auto rounded-2xl shadow-2xl"
              src="https://images.unsplash.com/photo-1677851802381-8283cfcc03b7" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Coffee Story</h2>
            <p className="text-lg text-gray-600 mb-6">
              At Two Stags Coffee, we believe that great coffee starts with great relationships.
              We've partnered with Dripshipper to bring you an exceptional selection of premium
              coffee beans from around the world.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Every bean is carefully selected, expertly roasted, and delivered fresh to ensure
              you experience the full flavor potential in every cup. Our commitment to quality
              and sustainability drives everything we do.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-amber-600 rounded-full"></div>
                <span className="text-gray-700">Ethically sourced from sustainable farms</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-amber-600 rounded-full"></div>
                <span className="text-gray-700">Small-batch roasting for optimal freshness</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-amber-600 rounded-full"></div>
                <span className="text-gray-700">Direct trade relationships with farmers</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;