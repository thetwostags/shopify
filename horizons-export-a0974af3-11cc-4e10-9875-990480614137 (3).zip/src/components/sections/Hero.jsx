import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = ({ handleFeatureClick }) => {
  return (
    <section id="home" className="pt-20 min-h-screen flex items-center relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-amber-100/50 to-orange-100/50"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <h1 className="text-5xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              Premium
              <span className="block bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                Artisan Coffee
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              Discover the world's finest coffee beans, carefully sourced and freshly roasted to perfection.
              Experience the difference that quality makes with every sip.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                onClick={handleFeatureClick}
                size="lg"
                className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-8 py-4 text-lg"
              >
                Shop Coffee <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                onClick={handleFeatureClick}
                variant="outline"
                size="lg"
                className="border-amber-600 text-amber-600 hover:bg-amber-50 px-8 py-4 text-lg"
              >
                Learn More
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10">
              <img
                alt="Premium coffee beans and brewing equipment showcasing artisan quality"
                className="w-full h-auto rounded-2xl shadow-2xl"
                src="https://images.unsplash.com/photo-1662165453173-1047613958b9" />
            </div>
            <div className="absolute -top-4 -right-4 w-full h-full bg-gradient-to-br from-amber-200 to-orange-200 rounded-2xl -z-10"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;