import React from 'react';
import { motion } from 'framer-motion';
import { Package, Zap, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PrivateLabel = ({ handleFeatureClick }) => {
  const features = [
    {
      icon: <Package className="h-8 w-8 text-white" />,
      title: "Custom Branding",
      description: "Your logo, your design. We put your brand front and center on every bag."
    },
    {
      icon: <Droplets className="h-8 w-8 text-white" />,
      title: "Proprietary Blends",
      description: "Access our exclusive coffee selection or work with us to create your own unique blends."
    },
    {
      icon: <Zap className="h-8 w-8 text-white" />,
      title: "Seamless Dropshipping",
      description: "No inventory, no hassle. We roast-on-demand and ship directly to your customers."
    }
  ];

  return (
    <section id="private-label" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Your Brand, Our Premium Coffee</h2>
            <p className="text-lg text-gray-600 mb-8">
              Launch your own coffee brand with our private label program. Powered by Dripshipper, we make it easy to sell premium, custom-branded coffee without holding any inventory. We handle the sourcing, roasting, and shipping, so you can focus on building your brand.
            </p>
            <Button
              onClick={handleFeatureClick}
              size="lg"
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-8 py-4 text-lg"
            >
              Start Your Coffee Brand
            </Button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-8 space-y-6 shadow-2xl">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="flex-shrink-0 bg-amber-600 p-3 rounded-full">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-1">{feature.title}</h3>
                    <p className="text-gray-400">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default PrivateLabel;