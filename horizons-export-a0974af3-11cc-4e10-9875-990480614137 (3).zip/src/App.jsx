import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';

import Header from '@/components/sections/Header';
import Hero from '@/components/sections/Hero';
import Features from '@/components/sections/Features';
import Products from '@/components/sections/Products';
import About from '@/components/sections/About';
import CTA from '@/components/sections/CTA';
import Footer from '@/components/sections/Footer';
import { shopifyClient } from '@/lib/shopify';

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const query = `
        query GetProducts {
          products(first: 4, query: "product_type:Coffee") {
            edges {
              node {
                id
                title
                descriptionHtml
                handle
                priceRange {
                  minVariantPrice {
                    amount
                    currencyCode
                  }
                }
                images(first: 1) {
                  edges {
                    node {
                      url
                      altText
                    }
                  }
                }
              }
            }
          }
        }
      `;

      try {
        const { data, errors } = await shopifyClient.request(query);
        if (errors) {
            throw new Error(errors.message || 'Error fetching products');
        }
        setProducts(data.products.edges.map(edge => edge.node));
      } catch (error) {
        console.error("Failed to fetch Shopify products:", error);
        toast({
          title: "Error fetching products",
          description: "Could not load products from Shopify. Please check your configuration in src/lib/shopify.js.",
          variant: "destructive",
        });
      }
    };

    fetchProducts();
  }, []);

  const handleFeatureClick = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <>
      <Helmet>
        <title>Two Stags Coffee - Premium Artisan Coffee Beans | Fresh Roasted Daily</title>
        <meta name="description" content="Discover premium artisan coffee beans at Two Stags Coffee. Fresh roasted daily, ethically sourced from the world's finest coffee regions. Free shipping on orders over $50." />
        <meta name="keywords" content="premium coffee, artisan coffee beans, fresh roasted coffee, specialty coffee, single origin coffee, coffee subscription, Two Stags Coffee" />
        <meta property="og:title" content="Two Stags Coffee - Premium Artisan Coffee Beans" />
        <meta property="og:description" content="Discover premium artisan coffee beans at Two Stags Coffee. Fresh roasted daily, ethically sourced from the world's finest coffee regions." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://twostagscoffee.com" />
        <link rel="canonical" href="https://twostagscoffee.com" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
        <Header handleFeatureClick={handleFeatureClick} />
        <main>
          <Hero handleFeatureClick={handleFeatureClick} />
          <Features />
          <Products coffeeProducts={products} handleFeatureClick={handleFeatureClick} />
          <About />
          <CTA handleFeatureClick={handleFeatureClick} />
        </main>
        <Footer handleFeatureClick={handleFeatureClick} />
        <Toaster />
      </div>
    </>
  );
}

export default App;